﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Composite
{
    class CompositeIterator : IEnumerator<MenuComponent>
    {
        Stack<IEnumerator<MenuComponent>> stack = new Stack<IEnumerator<MenuComponent>>();

        public CompositeIterator(IEnumerator<MenuComponent> iterator)
        {
            stack.Push(iterator);
        }

        public MenuComponent Current
        {
            get
            {
                IEnumerator<MenuComponent> iterator = stack.Peek();
                MenuComponent component = iterator.Current;

                if(component is Menu)
                {
                    stack.Push(component.CreateIterator());
                }
                return component;
            }
        }

        object IEnumerator.Current
        {
            get
            {
                return Current;
            }
        }

        public void Dispose()
        {
            throw new NotImplementedException();
        }

        public bool MoveNext()
        {
            if (stack.Count == 0)
                return false;

            IEnumerator<MenuComponent> iterator = stack.Peek();
            bool moveNext = iterator.MoveNext();
            if (!moveNext)
            {
                stack.Pop();
                return MoveNext();
            }
            else
                return true;
        }

        public void Reset()
        {
            throw new NotImplementedException();
        }
    }
}
