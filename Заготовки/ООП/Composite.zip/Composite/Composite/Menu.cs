﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Composite
{
    class Menu : MenuComponent
    {
        List<MenuComponent> menuComponents = new List<MenuComponent>();
        IEnumerator<MenuComponent> iterator = null;
        string name;
        string description;

        public Menu(string name, string description)
        {
            this.name = name;
            this.description = description;
        }

        public override void Add(MenuComponent menuComponent)
        {
            menuComponents.Add(menuComponent);
        }

        public override void Remove(MenuComponent menuComponent)
        {
            menuComponents.Remove(menuComponent);
        }

        public override MenuComponent GetChild(int i)
        {
            return menuComponents[i];
        }

        public override string GetName()
        {
            return name;
        }

        public override string GetDescription()
        {
            return description;
        }

        public override void Print()
        {
            Console.WriteLine(
                string.Format("\n{0}\nDescription: {1}\n------------", GetName(), GetDescription())
                );

            foreach (var item in menuComponents)
                item.Print();

            Console.WriteLine();
        }

        public override IEnumerator<MenuComponent> CreateIterator()
        {
            if (iterator == null)
                iterator = new CompositeIterator(menuComponents.GetEnumerator());

            return iterator;
        }
    }
}
