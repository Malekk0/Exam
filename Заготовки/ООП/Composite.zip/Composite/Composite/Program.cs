﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Composite
{
    class Program
    {
        static void Main(string[] args)
        {
            MenuComponent pancakeHouseMenu = new Menu("PANCAKE MENU", "BREAKFAST");
            MenuComponent dinerMenu = new Menu("DINNER MENU", "LUNCH");
            MenuComponent cafeMenu = new Menu("CAFE MENU", "Dinner");
            MenuComponent dessertMenu = new Menu("DESSERT MENU", "Dessert of course!");
            MenuComponent dessert2Menu = new Menu("DESSERT2 MENU", "Dessert of course!");

            MenuComponent allMenus = new Menu("ALL MENUS", "ALL MENUS COMBINED!");

            allMenus.Add(dinerMenu);
            allMenus.Add(cafeMenu);

            dinerMenu.Add(new MenuItem("Pasta", "Spaghetti with sauce", true, 3.89));

            dinerMenu.Add(dessertMenu);

            dessertMenu.Add(new MenuItem("Apple Pie", "Apple pie with flakey crust", true, 1.59));
            dessertMenu.Add(dessert2Menu);

            dessert2Menu.Add(new MenuItem("Strawberry", "aa", true, 1.59));

            allMenus.Print();
            
            IEnumerator<MenuComponent> iterator = allMenus.CreateIterator();
            while (iterator.MoveNext())
            {
                MenuComponent c = iterator.Current;
                if (c != null)
                    Console.WriteLine(c.GetName());
            }
        }
    }
}
