﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Composite
{
    class MenuItem : MenuComponent
    {
        string name;
        string description;
        bool vegetarian;
        double price;

        public MenuItem(string name, string description, bool vegetarian, double price)
        {
            this.name = name;
            this.description = description;
            this.vegetarian = vegetarian;
            this.price = price;
        }

        public override string GetName()
        {
            return name;
        }

        public override string GetDescription()
        {
            return description;
        }

        public override double GetPrice()
        {
            return price;
        }

        public override bool IsVegetarian()
        {
            return vegetarian;
        }

        public override void Print()
        {
            Console.WriteLine(string.Format("  {0} {1}\n  Price: {2}\n  Description: {3}", GetName(), IsVegetarian() ? "(v)" : "", GetPrice(), GetDescription()));
        }

        public override IEnumerator<MenuComponent> CreateIterator()
        {
            return new NullEnumerator();
        }
    }
}
