﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Weather
{
    class StatisticsDisplay : IObserver, IDisplayElement
    {
        private WeatherData weatherData;

        private List<double> allTimeTemperatures = new List<double>();

        private double averageTemperature;

        private double minTemperature;

        private double maxTemperature;


        public StatisticsDisplay(WeatherData wd)
        {
            weatherData = wd;
            weatherData.RegisterObserver(this);
        }

        public void Update()
        {
            double nowTemp = weatherData.GetTemperature();
            allTimeTemperatures.Add(nowTemp);

            if (allTimeTemperatures.Count == 1)
            {
                averageTemperature = nowTemp;
                minTemperature = nowTemp;
                maxTemperature = nowTemp;
            }
            else
            {

                if (minTemperature > nowTemp)
                    minTemperature = nowTemp;

                if (maxTemperature < nowTemp)
                    maxTemperature = nowTemp;

                averageTemperature = 0;
                for (int i = 0; i < allTimeTemperatures.Count; i++)
                    averageTemperature += allTimeTemperatures[i];

                averageTemperature /= allTimeTemperatures.Count;
            }

            Display();
        }

        public void Display()
        {
            Console.WriteLine("Статистика:\nСредняя температура: {0}\nМакс. температура: {1}\nМин. температура: {2}\n", averageTemperature, maxTemperature, minTemperature);
        }

        ~StatisticsDisplay()
        {
            weatherData.RemoveObserver(this);
        }
    }
}
