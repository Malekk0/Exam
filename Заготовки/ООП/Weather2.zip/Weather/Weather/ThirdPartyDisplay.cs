﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Weather
{
    class ThirdPartyDisplay : IObserver, IDisplayElement
    {
        private WeatherData weatherData;

        public ThirdPartyDisplay(WeatherData wd)
        {
            weatherData = wd;
            weatherData.RegisterObserver(this);
        }

        public void Update()
        {

        }

        public void Display()
        {
            
        }

        ~ThirdPartyDisplay()
        {
            weatherData.RemoveObserver(this);
        }
    }
}
