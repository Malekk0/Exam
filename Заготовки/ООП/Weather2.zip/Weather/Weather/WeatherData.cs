﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Weather
{
    class WeatherData : ISubject
    {
        private List<IObserver> observersList = new List<IObserver>();

        private Random rand = new Random();

        private double temperature;

        private double humidity;

        private double pressure;

        public void RegisterObserver(IObserver o)
        {
            if(!observersList.Contains(o))
                observersList.Add(o);
        }

        public void RemoveObserver(IObserver o)
        {
            if (observersList.Contains(o))
                observersList.Remove(o);
        }

        public void NotifyObservers()
        {
            foreach (IObserver o in observersList)
                o.Update();
        }

        public double GetTemperature()
        {
            return temperature;
        }

        public double GetHumidity()
        {
            return humidity;
        }

        public double GetPressure()
        {
            return pressure;
        }

        public void MeasurementsChanged()
        {
            temperature = rand.Next(-10, 30);
            humidity = rand.Next(0, 100);
            pressure = rand.Next(740, 780);

            NotifyObservers();
        }
    }
}
