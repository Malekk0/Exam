﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Weather
{
    class Program
    {
        private static WeatherData weatherData = new WeatherData();

        static void Main(string[] args)
        {
            IDisplayElement display1 = new ForecastDisplay(weatherData);
            IDisplayElement display2 = new StatisticsDisplay(weatherData);
            IDisplayElement display3 = new CurrentConditionsDisplay(weatherData);

            while (true)
            {
                Console.Clear();
                weatherData.MeasurementsChanged();

                Console.ReadKey();
            }
        }
    }
}
