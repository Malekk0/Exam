﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Weather
{
    class ForecastDisplay : IObserver, IDisplayElement
    {
        private WeatherData weatherData;

        private double currentPressure;

        public ForecastDisplay(WeatherData wd)
        {
            weatherData = wd;
            weatherData.RegisterObserver(this);
        }

        public void Update()
        {
            currentPressure = weatherData.GetPressure();

            Display();
        }

        public void Display()
        {
            Console.WriteLine("Прогноз:\n{0}\n", currentPressure > 760 ? "Завтра будет солнце!" : "Завтра будет дождик :p");
        }

        ~ForecastDisplay()
        {
            weatherData.RemoveObserver(this);
        }
    }
}
