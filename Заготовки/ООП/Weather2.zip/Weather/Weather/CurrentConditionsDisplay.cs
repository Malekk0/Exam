﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Weather
{
    class CurrentConditionsDisplay : IObserver, IDisplayElement
    {
        private WeatherData weatherData;

        private double currentTemperature;

        private double currentHumidity;

        private double currentPressure;

        public CurrentConditionsDisplay(WeatherData wd)
        {
            weatherData = wd;
            weatherData.RegisterObserver(this);
        }

        public void Update()
        {
            currentTemperature = weatherData.GetTemperature();
            currentHumidity = weatherData.GetHumidity();
            currentPressure = weatherData.GetPressure();

            Display();
        }

        public void Display()
        {
            Console.WriteLine("Сейчас:\nТемпература: {0}\nВлажность: {1}\nДавление: {2}\n", currentTemperature, currentHumidity, currentPressure);
        }

        ~CurrentConditionsDisplay()
        {
            weatherData.RemoveObserver(this);
        }
    }
}
