﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace DuckDuck
{
    class Program
    {
        static void Main(string[] args)
        {
            Duck duck = new HomeDuck();

            duck.SetFly(new DuckFly());
            duck.SetQuack(new DuckScream());

            duck.Display();
        }
    }
}
