﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace DuckDuck
{
    class ToysDuck : Duck
    {
        public override void Display()
        {
            Console.WriteLine("Toys duck, {0}, {1}", _flyOption.Fly(), _quackOption.Quack());
        }
    }
}
