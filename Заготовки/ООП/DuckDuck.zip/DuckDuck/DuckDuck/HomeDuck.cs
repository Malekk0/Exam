﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace DuckDuck
{
    class HomeDuck : Duck
    {
        public override void Display()
        {
            Console.WriteLine("Home duck, {0}, {1}", _flyOption.Fly(), _quackOption.Quack());
        }
    }
}
