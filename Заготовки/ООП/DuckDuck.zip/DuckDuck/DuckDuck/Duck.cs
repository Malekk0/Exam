﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace DuckDuck
{
    abstract class Duck
    {
        protected IFlyBehaviour _flyOption;
        protected IQuackBehaviour _quackOption;

        public void Quack()
        {
            Console.WriteLine(_quackOption.Quack());
        }

        public void Fly()
        {
            Console.WriteLine(_flyOption.Fly());
        }

        public void Swim()
        {
            Console.WriteLine("I can swim");
        }

        public void SetFly(IFlyBehaviour fly)
        {
            _flyOption = fly;
        }

        public void SetQuack(IQuackBehaviour quack)
        {
            _quackOption = quack;
        }

        public abstract void Display();
    }
}
