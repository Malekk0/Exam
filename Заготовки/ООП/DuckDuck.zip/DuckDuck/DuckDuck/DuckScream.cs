﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace DuckDuck
{
    class DuckScream : IQuackBehaviour
    {
        public string Quack()
        {
            return "SCREAaaaam";
        }
    }
}
