﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace DuckDuck
{
    class DuckNoFly : IFlyBehaviour
    {
        public string Fly()
        {
            return "I cant fly :C";
        }
    }
}
