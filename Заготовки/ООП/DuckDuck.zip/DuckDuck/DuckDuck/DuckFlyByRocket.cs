﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace DuckDuck
{
    class DuckFlyByRocket : IFlyBehaviour
    {
        public string Fly()
        {
            return "Rocket fly! Wooohooo!";
        }
    }
}
