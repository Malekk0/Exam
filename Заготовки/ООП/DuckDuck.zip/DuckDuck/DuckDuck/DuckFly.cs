﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace DuckDuck
{
    class DuckFly : IFlyBehaviour
    {
        public string Fly()
        {
            return "I can fly!!";
        }
    }
}
