﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace DuckDuck
{
    class MallarDuck : Duck
    {

        public override void  Display()
        {
            Console.WriteLine("Mallar duck, {0}, {1}", _flyOption.Fly(), _quackOption.Quack());
        }
    }
}
