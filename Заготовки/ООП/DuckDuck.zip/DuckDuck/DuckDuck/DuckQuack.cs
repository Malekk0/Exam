﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace DuckDuck
{
    class DuckQuack : IQuackBehaviour
    {
        public string Quack()
        {
            return "Qua-qua";
        }
    }
}
