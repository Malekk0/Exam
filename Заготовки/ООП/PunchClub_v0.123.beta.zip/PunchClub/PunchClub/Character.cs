﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PunchClub
{
    abstract class Character
    {
        public string Name { get; protected set; }

        public double Health { get; protected set; }

        public bool IsDead { get; protected set; }

        public ICharacterBehaviour Behaviour { get; set; }

        public Character()
        {
            IsDead = false;
        }

        public void TakeDamage(double dmg)
        {
            if (Health <= dmg)
            {
                Health = 0;
                IsDead = true;
            }
            else
                Health -= dmg;
        }

        public string About()
        {
            return string.Format("{0}: {1}", Name, Behaviour.DescriptionBehaviour());
        }

    }
}
