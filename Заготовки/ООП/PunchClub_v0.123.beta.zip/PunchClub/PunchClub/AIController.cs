﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PunchClub
{
    class AIController : Controller
    {
        private Random rand;

        public AIController(Character c)
        {
            rand = new Random();
            character = c;
        }

        public AIController(Character c, int seed)
        {
            rand = new Random(seed);
            character = c;
        }

        private int RandomTarget()
        {
            int rnd = rand.Next(0, 100);
            if (rnd < 35)
                return 1;
            if (rnd < 60)
                return 2;
            if (rnd < 80)
                return 3;

            return 4;
        }

        public override void GetTurn()
        {
            int attackInput, defendInput;

            attackInput = RandomTarget();
            defendInput = RandomTarget();

            SetBehaviour(attackInput, defendInput);
        }
    }
}
