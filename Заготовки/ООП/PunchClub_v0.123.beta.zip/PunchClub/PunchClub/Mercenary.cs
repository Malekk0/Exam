﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PunchClub
{
    class Mercenary : Character
    {
        private static Character _instance;
        public static Character Instance
        {
            get
            {
                if (_instance == null)
                    _instance = new Mercenary();

                return _instance;
            }
        }

        private Mercenary()
        {
            Name = "Mercenary";
            Health = 100;

            Behaviour = new IdleBehaviour();
        }
    }
}
