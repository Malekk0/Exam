﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PunchClub
{
    abstract class Controller
    {
        protected Character character;

        public void SetBehaviour(int attack, int defend)
        {
            character.Behaviour = new IdleBehaviour();

            switch (attack)
            {
                case 1:
                    character.Behaviour = new AttackHead(character.Behaviour);
                    break;
                case 2:
                    character.Behaviour = new AttackBody(character.Behaviour);
                    break;
                case 3:
                    character.Behaviour = new AttackHands(character.Behaviour);
                    break;
                case 4:
                    character.Behaviour = new AttackLegs(character.Behaviour);
                    break;
                default:

                    break;
            }
            switch (defend)
            {
                case 1:
                    character.Behaviour = new DefendHead(character.Behaviour);
                    break;
                case 2:
                    character.Behaviour = new DefendBody(character.Behaviour);
                    break;
                case 3:
                    character.Behaviour = new DefendHands(character.Behaviour);
                    break;
                case 4:
                    character.Behaviour = new DefendLegs(character.Behaviour);
                    break;
                default:

                    break;
            }
        }

        public abstract void GetTurn();
    }
}
