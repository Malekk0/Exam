﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PunchClub
{
    class IdleBehaviour : ICharacterBehaviour
    {
        public double AttackPower()
        {
            return 0;
        }

        public int AttackTarget()
        {
            return -1;
        }

        public int DefendTarget()
        {
            return -1;
        }

        public string DescriptionBehaviour()
        {
            return string.Empty;
        }
    }
}
