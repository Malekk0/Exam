﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Threading;

namespace PunchClub
{
    class Program
    {
        static void Main(string[] args)
        {
            Character hero = Hero.Instance;
            Character mercenary = Mercenary.Instance;

            Controller pc = new PlayerController(hero);
            Controller aic = new AIController(mercenary);

            Console.ForegroundColor = ConsoleColor.Yellow;
            Console.WriteLine("Welcome to PunchClub!\nToday are meeting a {0} and a {1} on the arena!", hero.Name, mercenary.Name);
            Console.ForegroundColor = ConsoleColor.Gray;

            while (true)
            {
                Console.ForegroundColor = ConsoleColor.White;
                pc.GetTurn();
                aic.GetTurn();
                Console.ForegroundColor = ConsoleColor.Gray;

                Console.WriteLine(hero.About());
                Console.WriteLine(mercenary.About());

                if (hero.Behaviour.AttackTarget() != mercenary.Behaviour.DefendTarget())
                {
                    double dmg = hero.Behaviour.AttackPower();
                    mercenary.TakeDamage(dmg);

                    Console.ForegroundColor = ConsoleColor.Green;
                    Console.WriteLine("{0} attacked {1} with {2} damage! {1} health is {3}", hero.Name, mercenary.Name, dmg, mercenary.Health);
                    Console.ForegroundColor = ConsoleColor.Gray;
                }
                else
                {
                    Console.ForegroundColor = ConsoleColor.Red;
                    Console.WriteLine("{0} parried {1} attack!", mercenary.Name, hero.Name);
                    Console.ForegroundColor = ConsoleColor.Gray;
                }

                if (mercenary.Behaviour.AttackTarget() != hero.Behaviour.DefendTarget())
                {
                    double dmg = mercenary.Behaviour.AttackPower();
                    hero.TakeDamage(mercenary.Behaviour.AttackPower());

                    Console.ForegroundColor = ConsoleColor.Red;
                    Console.WriteLine("{0} has taken {1} damage from {2}! {0} health is {3}", hero.Name, dmg, mercenary.Name, hero.Health);
                    Console.ForegroundColor = ConsoleColor.Gray;
                }
                else
                {
                    Console.ForegroundColor = ConsoleColor.Green;
                    Console.WriteLine("{0} parried {1} attack!", hero.Name, mercenary.Name);
                    Console.ForegroundColor = ConsoleColor.Gray;
                }

                if(hero.IsDead)
                {
                    Console.ForegroundColor = ConsoleColor.Red;
                    Console.WriteLine("{0} is dead. Game over! :C", hero.Name);
                    Console.ForegroundColor = ConsoleColor.Gray;
                    break;
                }
                if (mercenary.IsDead)
                {
                    Console.ForegroundColor = ConsoleColor.Green;
                    Console.WriteLine("{0} is dead. You win! C:", mercenary.Name);
                    Console.ForegroundColor = ConsoleColor.Gray;
                    break;
                }

                //Console.ReadKey();
            }
        }
    }
}
