﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PunchClub
{
    class PlayerController : Controller
    {
        public PlayerController(Character c)
        {
            character = c;
        }

        public override void GetTurn()
        {
            int attackInput, defendInput;

            character.Behaviour = new IdleBehaviour();

            Console.WriteLine("{0} turn:", character.Name);
            Console.WriteLine("Select attack target:\n1 - HEAD\n2 - BODY\n3 - HANDS\n4 - LEGS");
            attackInput = ConsoleInput();

            Console.WriteLine("Select defend target:\n1 - HEAD\n2 - BODY\n3 - HANDS\n4 - LEGS");
            defendInput = ConsoleInput();

            SetBehaviour(attackInput, defendInput);
        }

        private int ConsoleInput()
        {
            bool success = false;
            int input = -1;
            while (!success)
            {
                success = true;
                try
                {
                    input = Convert.ToInt32(Console.ReadLine());
                }
                catch { success = false; }
            }

            return input;
        }
    }
}
