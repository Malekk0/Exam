﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PunchClub
{
    class Hero : Character
    {
        private static Character _instance;
        public static Character Instance
        {
            get
            {
                if (_instance == null)
                    _instance = new Hero();

                return _instance;
            }
        }

        private Hero()
        {
            Name = "Hero";
            Health = 100;

            Behaviour = new IdleBehaviour();
        }
    }
}
