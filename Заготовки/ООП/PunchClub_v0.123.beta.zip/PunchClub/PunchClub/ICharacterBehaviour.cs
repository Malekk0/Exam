﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PunchClub
{
    interface ICharacterBehaviour
    {
        int AttackTarget();
        int DefendTarget();
        double AttackPower();
        string DescriptionBehaviour();
    }
}
