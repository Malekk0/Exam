﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PunchClub
{
    class AttackHead : BehaviourDecorator
    {

        public AttackHead(ICharacterBehaviour b) : base(b) { }

        public override double AttackPower()
        {
            return 20;
        }

        public override int AttackTarget()
        {
            return 1;
        }

        public override int DefendTarget()
        {
            return Component.DefendTarget();
        }

        public override string DescriptionBehaviour()
        {
            return string.Format("{0}Attack enemy HEAD with {1} damage. ", Component.DescriptionBehaviour(), AttackPower());
        }
    }
}
