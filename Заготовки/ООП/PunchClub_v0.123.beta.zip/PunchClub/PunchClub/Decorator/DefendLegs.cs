﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PunchClub
{
    class DefendLegs : BehaviourDecorator
    {
        public DefendLegs(ICharacterBehaviour b) : base(b) { }

        public override double AttackPower()
        {
            return Component.AttackPower();
        }

        public override int AttackTarget()
        {
            return Component.AttackTarget();
        }

        public override int DefendTarget()
        {
            return 4;
        }

        public override string DescriptionBehaviour()
        {
            return string.Format("{0}Defend his LEGS. ", Component.DescriptionBehaviour(), AttackPower());
        }
    }
}
