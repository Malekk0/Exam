﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PunchClub
{
    abstract class BehaviourDecorator : ICharacterBehaviour
    {
        public ICharacterBehaviour Component { get; private set; }

        public BehaviourDecorator(ICharacterBehaviour b)
        {
            Component = b;
        }

        public abstract double AttackPower();
        public abstract int AttackTarget();
        public abstract int DefendTarget();
        public abstract string DescriptionBehaviour();
    }
}
