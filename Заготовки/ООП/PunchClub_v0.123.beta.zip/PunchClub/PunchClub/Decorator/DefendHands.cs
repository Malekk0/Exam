﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PunchClub
{
    class DefendHands : BehaviourDecorator
    {
        public DefendHands(ICharacterBehaviour b) : base(b) { }

        public override double AttackPower()
        {
            return Component.AttackPower();
        }

        public override int AttackTarget()
        {
            return Component.AttackTarget();
        }

        public override int DefendTarget()
        {
            return 3;
        }

        public override string DescriptionBehaviour()
        {
            return string.Format("{0}Defend his HANDS. ", Component.DescriptionBehaviour(), AttackPower());
        }
    }
}
