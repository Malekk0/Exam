﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PunchClub
{
    class AttackBody : BehaviourDecorator
    {
        public AttackBody(ICharacterBehaviour b) : base(b) { }

        public override double AttackPower()
        {
            return 18;
        }

        public override int AttackTarget()
        {
            return 2;
        }

        public override int DefendTarget()
        {
            return Component.DefendTarget();
        }

        public override string DescriptionBehaviour()
        {
            return string.Format("{0}Attack enemy BODY with {1} damage. ", Component.DescriptionBehaviour(), AttackPower());
        }
    }
}
