﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PunchClub
{
    class AttackLegs : BehaviourDecorator
    {
        public AttackLegs(ICharacterBehaviour b) : base(b) { }

        public override double AttackPower()
        {
            return 15;
        }

        public override int AttackTarget()
        {
            return 4;
        }

        public override int DefendTarget()
        {
            return Component.DefendTarget();
        }

        public override string DescriptionBehaviour()
        {
            return string.Format("{0}Attack enemy LEGS with {1} damage. ", Component.DescriptionBehaviour(), AttackPower());
        }
    }
}
