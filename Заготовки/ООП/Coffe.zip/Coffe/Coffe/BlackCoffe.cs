﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Coffe
{
    class BlackCoffe : Coffe
    {
        public BlackCoffe() : base("Чёрный кофе") { }

        public override double GetCost()
        {
            return 10;
        }
    }
}
