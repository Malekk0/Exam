﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Coffe
{
    abstract class Coffe
    {
        public string Description { get; protected set; }

        public Coffe(string d)
        {
            Description = d;
        }

        public abstract double GetCost();
    }
}
