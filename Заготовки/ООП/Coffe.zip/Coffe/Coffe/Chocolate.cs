﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Coffe
{
    class Chocolate : Decorator
    {
        private Coffe coffe;

        public Chocolate(Coffe coffe) : base(coffe, coffe.Description + ", с шоколадом") { this.coffe = coffe; }

        public override double GetCost()
        {
            return coffe.GetCost() + 5;
        }

    }
}
