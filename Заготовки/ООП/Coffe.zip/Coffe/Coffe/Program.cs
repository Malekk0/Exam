﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Coffe
{
    class Program
    {
        static void Main(string[] args)
        {
            Coffe c = new BlackCoffe();
            c = new Milk(c);
            c = new Chocolate(c);

            Console.WriteLine(c.Description);
            Console.WriteLine(c.GetCost());
        }
    }
}
