﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Coffe
{
    class Milk : Decorator
    {
        private Coffe coffe;

        public Milk(Coffe coffe) : base(coffe, coffe.Description + ", с молоком") { this.coffe = coffe; }

        public override double GetCost()
        {
            return coffe.GetCost() + 3;
        }
    }
}
