﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Coffe
{
    abstract class Decorator : Coffe
    {
        public Decorator(Coffe coffe, string d) : base(d) { }
    }
}
