﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Factory
{
    abstract class Pizza
    {
        public void Prepare()
        {
            Console.WriteLine("Pizza prepared");
        }

        public void Bake()
        {
            Console.WriteLine("Pizza baked");
        }

        public void Cut()
        {
            Console.WriteLine("Pizza cut");
        }

        public void Box()
        {
            Console.WriteLine("Pizza boxed");
        }
    }
}
