﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Factory
{
    class Program
    {
        static void Main(string[] args)
        {
            StandartPizzaFactroy factory = new StandartPizzaFactroy();

            PizzaStore ps = new PizzaStore(factory);

            Console.WriteLine(ps.OrderPizza("Cheese").GetType());
        }
    }
}
