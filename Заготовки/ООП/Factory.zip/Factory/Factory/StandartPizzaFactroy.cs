﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Factory
{
    class StandartPizzaFactroy
    {
        public Pizza CreatePizza(string type)
        {
            Pizza pizza = null;

            if (type == "Cheese")
                pizza = new CheesePizza();
            else if (type == "Veggie")
                pizza = new VeggiePizza();

            return pizza;
        }
    }
}
