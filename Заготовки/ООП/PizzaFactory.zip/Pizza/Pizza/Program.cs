﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Pizza
{
    class Program
    {
        static void Main(string[] args)
        {
            PizzaStore cps = new CPizzaStore();
            PizzaStore nyps = new NYPizzaStore();

            cps.OrderPizza("Cheese");

            Console.WriteLine();

            nyps.OrderPizza("Cheese");

        }
    }
}
