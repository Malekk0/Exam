﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Pizza
{
    class NYPizzaStore : PizzaStore
    {
        protected override Pizza CreatePizza(string type)
        {
            Pizza pizza = null;

            if (type.Equals("Cheese", StringComparison.OrdinalIgnoreCase))
                pizza = new NYStyleCheesePizza();

            return pizza;
        }
    }
}
