﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Pizza
{
    class CStyleCheesePizza : Pizza
    {
        public CStyleCheesePizza()
        {
            name = "Chicago style cheese pizza";
            dough = "Extra Dough";
            sauce = "Tomato Sauce";

            toppings.Add("Mozzarella cheese");
        }

        public override void Cut()
        {
            Console.WriteLine("Cutting into square slices");
        } 
    }
}
