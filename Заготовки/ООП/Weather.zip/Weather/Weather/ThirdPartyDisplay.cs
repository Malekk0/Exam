﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Weather
{
    class ThirdPartyDisplay : IObserver, DisplayElement
    {
        public void Update()
        {

        }

        public void Display()
        {

        }
    }
}
