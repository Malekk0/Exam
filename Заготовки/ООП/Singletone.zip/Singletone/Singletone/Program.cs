﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Singletone
{
    class Program
    {
        static void Main(string[] args)
        {
            
            Hero h = Hero.GetInstance();

            h.TakeDamage(1000);
            h.TakeHealth(1000);
            Console.WriteLine(h.About());
            h.Respawn();
            Console.WriteLine(h.About());
            
            
            /*
            Hero[] arr = new Hero[100];

            Thread t1 = new Thread(Func);
            Thread t2 = new Thread(Func);
            t1.Start();
            t2.Start();
            t1.Join();
            t2.Join();

            Console.WriteLine(Hero.count);
            */
        }

        static void Func()
        {
            Hero.GetInstance();
        }
    }
}
