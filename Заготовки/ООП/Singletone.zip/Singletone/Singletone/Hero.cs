﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Singletone
{
    class Hero
    {
        private double _health;
        public double Health
        {
            get
            {
                return _health;
            }
            private set
            {
                if (IsDead)
                    return;

                _health = value;
                if (_health <= 0)
                {
                    _health = 0;
                    IsDead = true;
                }
            }
        }

        public bool IsDead { get; private set; }

        private static Hero instance;

        private static object mutex = new object();

        public static int count = 0;

        private Hero()
        {
            Health = 100;
            count++;
        }

        public void Respawn()
        {
            if (IsDead)
            {
                IsDead = false;
                Health = 100;
            }
        }

        public void TakeDamage(double dmg)
        {
            Health -= dmg;
        }

        public void TakeHealth(double heal)
        {
            Health += heal;
        }

        public string About()
        {
            return string.Format("Hero health = {0}. He is {1}", Health, IsDead ? "dead" : "alive");
        }

        public static Hero GetInstance()
        {
            if (instance == null)
                lock (mutex)
                    if(instance == null)
                        instance = new Hero();

            return instance;
        }
    }
}
