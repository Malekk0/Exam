﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace IteratorPattern
{
    class Program
    {
        static void Main(string[] args)
        {
            DinerMenu dinerMenu = new DinerMenu();

            Iterator dinerMenuIterator = dinerMenu.createIterator();

            while(dinerMenuIterator.HasNext())
                Console.WriteLine(((MenuItem)dinerMenuIterator.Next()).GetName());


        }
    }
}
