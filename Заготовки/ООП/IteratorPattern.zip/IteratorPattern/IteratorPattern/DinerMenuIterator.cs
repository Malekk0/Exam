﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace IteratorPattern
{
    class DinerMenuIterator : Iterator
    {
        MenuItem[] items;
        int position = 0;

        public DinerMenuIterator(MenuItem[] items)
        {
            this.items = items;
        }

        public object Next()
        {
            return items[position++];
        }

        public object Back()
        {
            position -= 1;
            return items[position];
        }

        public bool HasBack()
        {
            return (position <= 0) ? false : true;
        }

        public bool HasNext()
        {
            return (position >= items.Length || items[position] == null) ? false : true;
        }
    }
}
