﻿using System;
using System.Collections.Generic;
using System.Collections;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AdapterEnumerator
{
    class Program
    {
        static void Main(string[] args)
        {
            Iterator iter = new Iterator();

            IEnumerator enumerator = new IteratorEnumerator(iter);

            Console.WriteLine("IteratorEnumerator:");
            while (enumerator.MoveNext())
            {
                Console.WriteLine(enumerator.Current);
            }



            Iterator iter2 = new Iterator();
            Console.WriteLine("\nIterator:");
            while (true)
            {
                iter2.MoveNext();
                if (!iter2.HasMoreElements())
                    break;

                Console.WriteLine(iter2.CurrectElement());
            }
        }
    }
}
