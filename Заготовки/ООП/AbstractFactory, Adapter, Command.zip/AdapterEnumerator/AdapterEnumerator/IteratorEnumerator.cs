﻿using System;
using System.Collections.Generic;
using System.Collections;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AdapterEnumerator
{
    class IteratorEnumerator : IEnumerator
    {
        private IIterator iterator;

        public object Current
        {
            get
            {
                return iterator.CurrectElement();
            }
        }

        public IteratorEnumerator(IIterator iterator)
        {
            this.iterator = iterator;
        }

        public bool MoveNext()
        {
            iterator.MoveNext();

            return iterator.HasMoreElements();
        }

        public void Reset()
        {
            throw new InvalidOperationException(); ////
        }
    }
}
