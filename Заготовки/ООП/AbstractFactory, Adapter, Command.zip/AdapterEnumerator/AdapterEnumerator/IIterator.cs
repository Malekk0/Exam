﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AdapterEnumerator
{
    interface IIterator
    {
        bool HasMoreElements();
        object CurrectElement();
        void MoveNext();
    }
}
