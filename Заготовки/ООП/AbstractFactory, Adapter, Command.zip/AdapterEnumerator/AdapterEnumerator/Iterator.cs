﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AdapterEnumerator
{
    class Iterator : IIterator
    {
        private int[] list = new int[ELEMENTS_COUNT];

        private int position = -1;

        private const int ELEMENTS_COUNT = 5;

        public Iterator()
        {
            for (int i = 0; i < ELEMENTS_COUNT; i++)
                list[i] = i;
        }
        
        public bool HasMoreElements()
        {
            return position < ELEMENTS_COUNT ? true : false;
        }

        public object CurrectElement()
        {
            return list[position];
        }

        public void MoveNext()
        {
            position++;
        }
    }
}
