﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Command
{
    class Light : ILight
    {
        public string Name { get; set; }

        public Light(string name)
        {
            Name = name;
        }

        public void On()
        {
            Console.WriteLine("The light is on! [{0}]", Name);
        }

        public void Off()
        {
            Console.WriteLine("The light is off! [{0}]", Name);
        }
    }
}
