﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Command
{
    class GarageDoor : IGarageDoor
    {
        public void Down()
        {
            Console.WriteLine("Garage door is close!");
        }

        public void LightOff()
        {
            Console.WriteLine("Garage light off");
        }

        public void LightOn()
        {
            Console.WriteLine("Garage light on");
        }

        public void Stop()
        {
            Console.WriteLine("Garage door has stopped");
        }

        public void Up()
        {
            Console.WriteLine("Garage door is open!");
        }
    }
}
