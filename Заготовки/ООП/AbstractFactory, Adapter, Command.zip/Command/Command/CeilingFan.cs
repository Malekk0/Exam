﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Command
{
    class CeilingFan : IFan
    {
        public const int HIGH = 3;
        public const int MEDIUM = 2;
        public const int LOW = 1;
        public const int OFF = 0;
        private int speed;

        public int GetSpeed()
        {
            return speed;
        }

        public void High()
        {
            speed = HIGH;
            Console.WriteLine("Fan Max speed");
        }

        public void Low()
        {
            speed = LOW;
            Console.WriteLine("Fan Low speed");
        }

        public void Medium()
        {
            speed = MEDIUM;
            Console.WriteLine("Fan Medium speed");
        }

        public void Off()
        {
            speed = OFF;
            Console.WriteLine("Fan is off");
        }
    }
}
