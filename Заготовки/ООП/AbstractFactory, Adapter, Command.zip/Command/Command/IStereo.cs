﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Command
{
    interface IStereo
    {
        void On();
        void Off();
        void SetCD();
        void SetVolume(int value);
    }
}
