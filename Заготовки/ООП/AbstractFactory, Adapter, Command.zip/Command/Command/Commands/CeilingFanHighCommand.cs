﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Command
{
    class CeilingFanHighCommand : ICommand
    {
        IFan fan;
        int prevSpeed;

        public CeilingFanHighCommand(IFan fan)
        {
            this.fan = fan;
        }

        public void Execute()
        {
            prevSpeed = fan.GetSpeed();
            fan.High();
        }

        public void Undo()
        {
            if (prevSpeed == CeilingFan.LOW)
                fan.Low();
            else if (prevSpeed == CeilingFan.MEDIUM)
                fan.Medium();
            else if (prevSpeed == CeilingFan.HIGH)
                fan.High();
            else if (prevSpeed == CeilingFan.OFF)
                fan.Off();
        }
    }
}
