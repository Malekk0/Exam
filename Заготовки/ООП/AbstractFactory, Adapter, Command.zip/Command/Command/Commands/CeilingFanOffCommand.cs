﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Command
{
    class CeilingFanOffCommand : ICommand
    {
        IFan fan;
        int prevSpeed;

        public CeilingFanOffCommand(IFan fan)
        {
            this.fan = fan;
        }

        public void Execute()
        {
            prevSpeed = fan.GetSpeed();
            fan.Off();
        }

        public void Undo()
        {
            if (prevSpeed == CeilingFan.LOW)
                fan.Low();
            else if (prevSpeed == CeilingFan.MEDIUM)
                fan.Medium();
            else if (prevSpeed == CeilingFan.HIGH)
                fan.High();
            else if (prevSpeed == CeilingFan.OFF)
                fan.Off();
        }
    }
}
