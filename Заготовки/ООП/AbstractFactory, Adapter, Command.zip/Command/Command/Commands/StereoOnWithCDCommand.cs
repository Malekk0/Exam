﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Command
{
    class StereoOnWithCDCommand : ICommand
    {
        IStereo stereo;

        public StereoOnWithCDCommand(IStereo stereo)
        {
            this.stereo = stereo;
        }

        public void Execute()
        {
            stereo.On();
            stereo.SetCD();
            stereo.SetVolume(12);
        }

        public void Undo()
        {
            stereo.Off();
        }
    }
}
