﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Command
{
    class Stereo : IStereo
    {
        public void Off()
        {
            Console.WriteLine("Stereo is off");
        }

        public void On()
        {
            Console.WriteLine("Stereo is on");
        }

        public void SetCD()
        {
            Console.WriteLine("Setting cd...");
        }

        public void SetVolume(int value)
        {
            Console.WriteLine("Set volume to {0}", value);
        }
    }
}
