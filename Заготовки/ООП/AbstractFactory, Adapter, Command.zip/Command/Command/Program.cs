﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Command
{
    class Program
    {
        static void Main(string[] args)
        {
            RemoteControl control = new RemoteControl();

            Light livingRoomLight = new Light("Living room");
            Light kitchenLight = new Light("Kitchen");
            GarageDoor garageDoor = new GarageDoor();
            Stereo stereo = new Stereo();
            CeilingFan fan = new CeilingFan();

            LightOnCommand livingRoomLightOn = new LightOnCommand(livingRoomLight);
            LightOffCommand livingRoomLightOff = new LightOffCommand(livingRoomLight);
            LightOnCommand kitchenLightOn = new LightOnCommand(kitchenLight);
            LightOffCommand kitchenLightOff = new LightOffCommand(kitchenLight);

            GarageDoorOpenCommand garageDoorOpen = new GarageDoorOpenCommand(garageDoor);
            GarageDoorCloseCommand garageDoorClose = new GarageDoorCloseCommand(garageDoor);

            StereoOnWithCDCommand stereoOnWithCD = new StereoOnWithCDCommand(stereo);
            StereoOffCommand stereoOff = new StereoOffCommand(stereo);

            CeilingFanHighCommand fanHigh = new CeilingFanHighCommand(fan);
            CeilingFanOffCommand fanOff = new CeilingFanOffCommand(fan);

            ICommand[] partyOn = new ICommand[] { stereoOnWithCD, fanHigh, livingRoomLightOn };
            ICommand[] partyOff = new ICommand[] { stereoOff, fanOff, livingRoomLightOff };

            MacroCommand partyOnMacro = new MacroCommand(partyOn);
            MacroCommand partyOffMacro = new MacroCommand(partyOff);

            control.SetCommand(0, livingRoomLightOn, livingRoomLightOff);
            control.SetCommand(1, kitchenLightOn, kitchenLightOff);
            control.SetCommand(2, garageDoorOpen, garageDoorClose);
            control.SetCommand(3, stereoOnWithCD, stereoOff);
            control.SetCommand(4, fanHigh, fanOff);
            control.SetCommand(5, partyOnMacro, partyOffMacro);

            Console.WriteLine(control);

            for (int i = 0; i < 6; i++)
            {
                control.OnButtonWasPushed(i);
                control.OffButtonWasPushed(i);
                Console.WriteLine("---");
            }
            control.UndoButtonWasPushed();
        }
    }
}
