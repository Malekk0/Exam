﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Command
{
    interface IGarageDoor
    {
        void Up();
        void Down();
        void Stop();
        void LightOn();
        void LightOff();
    }
}
