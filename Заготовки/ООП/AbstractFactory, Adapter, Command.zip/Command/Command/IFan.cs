﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Command
{
    interface IFan
    {
        void High();
        void Medium();
        void Low();
        void Off();
        int GetSpeed();
    }
}
