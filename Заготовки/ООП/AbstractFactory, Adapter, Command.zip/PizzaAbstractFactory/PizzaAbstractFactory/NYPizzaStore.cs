﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PizzaAbstractFactory
{
    class NYPizzaStore : PizzaStore
    {
        protected override Pizza CreatePizza(string type)
        {
            Pizza pizza = null;
            IPizzaIngredientFactory factory = new NYPizzaIngredientFactory();

            if(type.Equals("Cheese", StringComparison.InvariantCultureIgnoreCase))
            {
                pizza = new CheesePizza(factory);
                pizza.SetName("NY Cheese pizza");
            }

            if (type.Equals("Clam", StringComparison.InvariantCultureIgnoreCase))
            {
                pizza = new ClamPizza(factory);
                pizza.SetName("NY Clam pizza");
            }

            return pizza;
        }
    }
}
