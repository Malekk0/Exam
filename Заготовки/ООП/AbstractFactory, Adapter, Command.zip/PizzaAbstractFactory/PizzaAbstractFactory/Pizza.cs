﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PizzaAbstractFactory
{
    abstract class Pizza
    {
        protected String name;
        protected Dough dough;
        protected Sauce sauce;
        protected Veggies[] veggies;
        protected Cheese cheese;
        protected Pepperoni pepperoni;
        protected Clams clams;

        public abstract void Prepare();

        public void Bake()
        {
            Console.WriteLine("Bake for 25 min at 350");
        }

        public void Cut()
        {
            Console.WriteLine("Cutting into diagonal slices");
        }

        public void Box()
        {
            Console.WriteLine("Place pizza in official PizzaStore box");
        }

        public void SetName(string n)
        {
            name = n;
        }

        public string GetName()
        {
            return name;
        }

        public override string ToString()
        {
            return name;
        }
    }
}
